import React, { Component } from 'react'
import Home from './home/Home'

class App extends Component {
  constructor () {
    super()
    this.state = {
      selectedTab: 'home'
    }
    
  }
  render () {
    const { toggleSideMenu } = this.props
    return (
      
          <Home toggleSideMenu={toggleSideMenu} />
      
    )
  }
}
export default App
