import PricingNav from './PricingNav'
import { connect } from 'react-redux'

function mapStateToProps (state) {
  return {}
}

function mapDispatchToProps (dispatch) {
  return {}
}

// export default connect(mapStateToProps, mapDispatchToProps)(AboutNav)
export default PricingNav
