import ContactNav from './ContactNav'
import { connect } from 'react-redux'

function mapStateToProps (state) {
  return {}
}

function mapDispatchToProps (dispatch) {
  return {}
}

// export default connect(mapStateToProps, mapDispatchToProps)(ContactNav)
export default ContactNav
