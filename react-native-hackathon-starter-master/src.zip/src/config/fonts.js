/**
 * @providesModule HSFonts
 */

export default {
  ios: {
    regular: 'System',
    light: 'System',
    lightItalic: 'System',
    bold: 'System',
    boldItalic: 'System',
    black: 'System',
    blackItalic: 'System'
  },
  android: {
    regular: 'Roboto',
    italic: 'Roboto-Italic',
    thin: 'Roboto-Thin',
    thinItalic: 'Roboto-ThinItalic',
    light: 'Roboto-Light',
    lightItalic: 'Roboto-LightItalic',
    medium: 'Roboto-Medium',
    mediumItalic: 'Roboto-MediumItalic',
    bold: 'Roboto-Bold',
    boldItalic: 'Roboto-BoldItalic',
    condensed: 'RobotoCondensed-Regular',
    condensedItalic: 'RobotoCondensed-Italic'
  }
}
