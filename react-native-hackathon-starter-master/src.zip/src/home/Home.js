import React, { Component } from 'react'
import { ScrollView, StyleSheet} from 'react-native'

import {
  Text,
  Button
} from 'react-native-elements'

class Home extends Component {
  render () {
    const { toggleSideMenu } = this.props
    return (
      <ScrollView style={{backgroundColor: 'black'}}>
        <Button
          buttonStyle={styles.button}
          onPress={() => toggleSideMenu()}
          title='TOGGLE SIDE MENU'/>
      </ScrollView>
    )
  }
}

let styles = StyleSheet.create({
  button: {
    marginTop: 64
  }
})

export default Home
