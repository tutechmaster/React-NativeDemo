import AboutNav from './AboutNav'
import { connect } from 'react-redux'

function mapStateToProps (state) {
  return {}
}

function mapDispatchToProps (dispatch) {
  return {}
}

// export default connect(mapStateToProps, mapDispatchToProps)(AboutNav)
export default AboutNav
